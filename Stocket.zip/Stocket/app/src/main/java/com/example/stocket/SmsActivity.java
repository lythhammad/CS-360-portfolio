package com.example.stocket;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsActivity extends AppCompatActivity {

    // 1. CONSTANTS
    private static final int SMS_PERMISSION_CODE = 100;

    // 2. CLASS FIELDS (DECLARATIONS)
    private Button allowButton, denyButton;

    // 3. LIFECYCLE METHOD
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        // 4. INITIALIZATION (View Binding)
        allowButton = findViewById(R.id.btnAllow);
        denyButton = findViewById(R.id.btnDeny);

        // 5. EVENT LISTENERS
        allowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestSmsPermission();
            }
        });

        denyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // User denies via button
                goToMainActivity(false);
            }
        });
    }

    // 6. PERMISSION REQUEST LOGIC
    private void requestSmsPermission() {
        // Check if permission is NOT currently granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            // Request permission from the user
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE
            );

        } else {
            // Permission is already granted (shouldn't happen often if flow is correct)
            goToMainActivity(true);
        }
    }

    // 7. PERMISSION RESPONSE HANDLER
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            // Check if the result array is non-empty and the grant result is GRANTED
            boolean permissionGranted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            goToMainActivity(permissionGranted);
        }
    }

    // 8. NAVIGATION HANDLER
    private void goToMainActivity(boolean smsEnabled) {
        // Prepare intent to launch MainActivity
        Intent intent = new Intent(SmsActivity.this, MainActivity.class);

        // Pass the SMS status and the username (retrieved from the starting intent)
        intent.putExtra("smsEnabled", smsEnabled);
        intent.putExtra("username", getIntent().getStringExtra("username"));

        startActivity(intent);

        // Essential: Close this activity so the user cannot navigate back to the prompt
        finish();
    }
}