package com.example.stocket;

import android.app.AlertDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    // 1. CLASS FIELDS (DECLARATIONS)
    private DatabaseHelper dbHelper;
    private RecyclerView recyclerView;
    private InventoryAdapter adapter;
    private ArrayList<InventoryItem> itemList;
    private Button btnAdd;

    // 2. LIFECYCLE METHOD
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 3. INITIALIZATION
        dbHelper = new DatabaseHelper(this);

        recyclerView = findViewById(R.id.recyclerViewItems);
        btnAdd = findViewById(R.id.btnAdd);

        itemList = new ArrayList<>();

        // 4. ADAPTER AND RECYCLERVIEW SETUP
        setupRecyclerView();

        // 5. EVENT LISTENERS
        btnAdd.setOnClickListener(v -> showAddDialog());

        // 6. INITIAL DATA LOAD
        loadItems();
    }

    // 7. SETUP METHODS
    private void setupRecyclerView() {
        // Defines the listener logic for CUD (Create, Update, Delete) operations
        adapter = new InventoryAdapter(this, itemList, new InventoryAdapter.OnItemClickListener() {
            @Override
            public void onIncreaseClick(InventoryItem item) {
                item.setQuantity(item.getQuantity() + 1);
                dbHelper.updateItem(item.getId(), item.getName(), item.getQuantity());
                loadItems();
            }

            @Override
            public void onDecreaseClick(InventoryItem item) {
                if(item.getQuantity() > 0) {
                    item.setQuantity(item.getQuantity() - 1);
                    dbHelper.updateItem(item.getId(), item.getName(), item.getQuantity());
                    loadItems();
                }
            }

            @Override
            public void onDeleteClick(InventoryItem item) {
                dbHelper.deleteItem(item.getId());
                loadItems();
            }
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }

    // 8. DATA/CRUD METHODS (Read)
    private void loadItems() {
        itemList.clear();
        Cursor cursor = dbHelper.getAllItems();

        if(cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_NAME));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_QUANTITY));

                itemList.add(new InventoryItem(id, name, quantity));
            } while(cursor.moveToNext());
        }
        cursor.close();
        adapter.notifyDataSetChanged();
    }

    // 9. UI DIALOG METHODS (Create)
    private void showAddDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add New Item");

        final EditText input = new EditText(this);
        input.setHint("Item name");
        builder.setView(input);

        builder.setPositiveButton("Add", (dialog, which) -> {
            String itemName = input.getText().toString().trim();
            if(!itemName.isEmpty()) {
                // Initial quantity set to 0
                dbHelper.addItem(itemName, 0);
                loadItems();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        builder.show();
    }
}