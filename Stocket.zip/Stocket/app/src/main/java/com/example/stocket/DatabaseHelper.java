package com.example.stocket;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;
public class DatabaseHelper extends SQLiteOpenHelper {

    // 1. CONSTANTS
    private static final String DATABASE_NAME = "stocket.db";
    // *** CRITICAL FIX: INCREMENT VERSION to force database recreation and prevent "no such table" error ***
    private static final int DATABASE_VERSION = 2;

    // User table
    public static final String TABLE_USERS = "users";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";
    // *** NECESSARY ADDITION: Column to store user's SMS preference (1=true, 0=false) ***
    public static final String COLUMN_SMS_ENABLED = "sms_enabled";

    // Inventory table
    public static final String TABLE_INVENTORY = "inventory";
    public static final String COLUMN_ITEM_ID = "item_id";
    public static final String COLUMN_ITEM_NAME = "item_name";
    public static final String COLUMN_ITEM_QUANTITY = "item_quantity";


    // 2. CONSTRUCTOR
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // 3. LIFECYCLE METHODS
    @Override
    public void onCreate(SQLiteDatabase db) {
        // User table creation (Updated to include COLUMN_SMS_ENABLED)
        String CREATE_USER_TABLE = "CREATE TABLE " + TABLE_USERS + " ("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_USERNAME + " TEXT UNIQUE, "
                + COLUMN_PASSWORD + " TEXT,"
                + COLUMN_SMS_ENABLED + " INTEGER DEFAULT 0" // Default to 0 (false)
                + ")";
        db.execSQL(CREATE_USER_TABLE);

        // Inventory table creation
        String CREATE_INVENTORY_TABLE = "CREATE TABLE " + TABLE_INVENTORY + " ("
                + COLUMN_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_ITEM_NAME + " TEXT, "
                + COLUMN_ITEM_QUANTITY + " INTEGER"
                + ")";
        db.execSQL(CREATE_INVENTORY_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop and recreate all tables on version upgrade
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        onCreate(db);
    }

    // 4. USER CRUD AND CHECK METHODS

    // CREATE User
    public boolean createUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);
        values.put(COLUMN_SMS_ENABLED, 0); // Initialize SMS to false (0)

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    // READ User Check (Login)
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + "=? AND " + COLUMN_PASSWORD + "=?",
                new String[]{username, password}
        );

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        // db.close(); // Not strictly required for rawQuery but good practice
        return exists;
    }

    // READ Username Exists Check
    public boolean usernameExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + "=?",
                new String[]{username}
        );

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        // db.close();
        return exists;
    }

    // 5. SMS PREFERENCE METHODS (NECESSARY ADDITIONS)

    // UPDATE SMS Preference (Used by SmsActivity)
    public void updateSmsPreference(String username, boolean enabled) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_SMS_ENABLED, enabled ? 1 : 0);

        db.update(TABLE_USERS, values, COLUMN_USERNAME + "=?",
                new String[]{username});
        // db.close();
    }

    // READ SMS Preference (Optional, if you want to check user's soft preference)
    public boolean isSmsEnabled(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT " + COLUMN_SMS_ENABLED + " FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + "=?",
                new String[]{username}
        );

        boolean enabled = false;
        if (cursor.moveToFirst()) {
            // Read the integer (1 or 0) and convert to boolean
            enabled = cursor.getInt(0) == 1;
        }
        cursor.close();
        // db.close();
        return enabled;
    }

    // 6. INVENTORY CRUD METHODS

    // CREATE
    public boolean addItem(String name, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_NAME, name);
        values.put(COLUMN_ITEM_QUANTITY, quantity);

        long result = db.insert(TABLE_INVENTORY, null, values);
        // db.close();
        return result != -1;
    }

    // READ
    public Cursor getAllItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_INVENTORY, null);
    }

    // UPDATE
    public void updateItem(int id, String name, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_NAME, name);
        values.put(COLUMN_ITEM_QUANTITY, quantity);

        db.update(TABLE_INVENTORY, values, COLUMN_ITEM_ID + "=?",
                new String[]{String.valueOf(id)});
        // db.close();
    }

    // DELETE
    public void deleteItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_INVENTORY, COLUMN_ITEM_ID + "=?",
                new String[]{String.valueOf(id)});
        // db.close();
    }
}