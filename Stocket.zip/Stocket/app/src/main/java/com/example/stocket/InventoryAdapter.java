package com.example.stocket;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ItemViewHolder> {

    private Context context;
    private ArrayList<InventoryItem> itemList;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onIncreaseClick(InventoryItem item);
        void onDecreaseClick(InventoryItem item);
        void onDeleteClick(InventoryItem item);
    }

    public InventoryAdapter(Context context, ArrayList<InventoryItem> itemList, OnItemClickListener listener) {
        this.context = context;
        this.itemList = itemList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_inventory, parent, false);
        return new ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        InventoryItem item = itemList.get(position);

        holder.nameText.setText(item.getName());
        holder.quantityText.setText("Qty: " + item.getQuantity());

        holder.increaseBtn.setOnClickListener(v -> listener.onIncreaseClick(item));
        holder.decreaseBtn.setOnClickListener(v -> listener.onDecreaseClick(item));
        holder.deleteBtn.setOnClickListener(v -> listener.onDeleteClick(item));
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    public static class ItemViewHolder extends RecyclerView.ViewHolder {
        TextView nameText, quantityText;
        Button increaseBtn, decreaseBtn, deleteBtn;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);

            nameText = itemView.findViewById(R.id.itemNameText);
            quantityText = itemView.findViewById(R.id.itemQuantityText);
            increaseBtn = itemView.findViewById(R.id.btnIncrease);
            decreaseBtn = itemView.findViewById(R.id.btnDecrease);
            deleteBtn = itemView.findViewById(R.id.btnDelete);
        }
    }
}
