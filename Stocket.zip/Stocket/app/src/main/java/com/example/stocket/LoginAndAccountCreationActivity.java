package com.example.stocket;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.BreakIterator;

public class LoginAndAccountCreationActivity extends AppCompatActivity {

    EditText usernameInput, passwordInput;
    Button loginButton, createAccountButton;
    DatabaseHelper dbHelper;



    DatabaseHelper db;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        dbHelper = new DatabaseHelper(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_and_account_creation);

        db = new DatabaseHelper(this);

        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.passwordInput);
        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createAccountButton);


        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String user = usernameInput.getText().toString().trim();
                String pass = passwordInput.getText().toString().trim();

                if (dbHelper.checkUser(user, pass)) {
                    Intent intent = new Intent(LoginAndAccountCreationActivity.this, SmsActivity.class);
                    intent.putExtra("username", user);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(LoginAndAccountCreationActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                }
            }
        });

        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String user = usernameInput.getText().toString().trim();
                String pass = passwordInput.getText().toString().trim();

                if (dbHelper.usernameExists(user)) {
                    Toast.makeText(LoginAndAccountCreationActivity.this, "Username already taken", Toast.LENGTH_SHORT).show();
                } else {
                    boolean created = dbHelper.createUser(user, pass);
                    if (created) {
                        Toast.makeText(LoginAndAccountCreationActivity.this, "Account created, please log in", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(LoginAndAccountCreationActivity.this, "Error creating account", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
